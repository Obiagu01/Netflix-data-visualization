library(tidyverse)
library(ggplot2)
?ggplot2
head(netflix_shows_movies)
#lets rename column listed_in to Genre
library(dplyr)
netflix_shows_movies<-netflix_shows_movies %>% 
  rename(Genre = listed_in ,Show_id =show_id)

netflix_shows_movies<-netflix_shows_movies %>% 
  rename(Show_id =show_id)

netflix_shows_movies<-netflix_shows_movies %>% 
  rename(Type =type, Title = title,Director =director,Cast = cast, Country = country)

netflix_shows_movies<-netflix_shows_movies %>% 
  rename(Date_added =date_added,Release_year = release_year,Rating =rating,Duration =duration,Description =description)
 #visualize the dataset
head(netflix_shows_movies[1:12])
head(netflix_shows_movies,20)
View(netflix_shows_movies[1:20, ])

colnames(netflix_shows_movies)

genre_counts <- table(df$Genre)
genre_counts_sorted <- sort(genre_counts, decreasing = TRUE)
print(head(genre_counts_sorted, 10))


library(dplyr)

genre_counts <- table(df$Genre)
genre_counts_sorted <- sort(genre_counts, decreasing = TRUE)
print(head(genre_counts_sorted, 10))


genre_counts <- df %>%
  count(Genre, sort = TRUE)

print(head(genre_counts, 10))

genre_counts = df['Genre'].value_counts()
print(genre_counts.head(10))

# Count types (Movie/TV Show)
netflix_shows_movies %>%
  count(Genre) %>%
  ggplot(aes(x = type, y = n, fill = type)) +
  geom_bar

# Load necessary libraries
library(tidyverse)
genre_counts <- netflix_shows_movies

# Load the dataset
netflix_data <- read_csv("netflix_shows_movies.csv")

# Split and unnest the genres
genre_counts <- netflix_shows_movies %>%
  filter(!is.na(Genre)) %>%
  separate_rows(Genre, sep = ",\\s*") %>%
  count(Genre, sort = TRUE) %>%
  top_n(10, n)

# Plot the top 10 genres
ggplot(genre_counts, aes(x = reorder(Genre, n), y = n)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  coord_flip() +
  labs(title = "Top 10 Watched Genres on Netflix",
       x = "Genre",
       y = "Number of Shows/Movies") +
  theme_minimal()

